# Tripleten web_project_around
Neste projeto, utilizei habilidades aprendidas em todos os sprints até agora. Utilizamos HTML e CSS para criar a página e seus estilos e, em conjunto, incluímos o JavaScript que foi o tema estudado neste sprint.

Com o JavaScript, foi possível criar uma página mais interativa, utilizando funcionalidades como: "const" e "addEventListener" na qual um botão de edição abre um formulário que nos permite mudar informações na página, dando um nível a mais na interatividade para o projeto.

No futuro (próximo), gostaria de aprimorar a página dando mais interação e tornando-a mais eficiente.